from externals.hachoir.wx.main import main
main()
