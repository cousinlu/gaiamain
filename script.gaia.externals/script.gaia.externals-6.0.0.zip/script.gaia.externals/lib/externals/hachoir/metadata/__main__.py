from externals.hachoir.metadata.main import main
main()
